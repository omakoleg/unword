#h1 About
Chrome extension to store selected chunks of text to indexedDb. 

List of words could be viewed in extension popup.

#h1 License

Licensed under [wtfpl](http://www.wtfpl.net/)
